// import React from 'react'

// const Breadcrumb = () => {
//   return (
//     <div className="row page-titles">
//   <div className="col-md-5 col-12 align-self-center">
//     <h3 className="text-themecolor mb-0">Profile Page</h3>
//     <ol className="breadcrumb mb-0 p-0 bg-transparent">
//       <li className="breadcrumb-item">
//         <a href="javascript:void(0)">Home</a>
//       </li>
//       <li className="breadcrumb-item active">Profile Page</li>
//     </ol>
//   </div>
//   <div className="col-md-7 col-12 align-self-center d-none d-md-block">
//     <div className="d-flex mt-2 justify-content-end">
//       <div className="d-flex mr-3 ml-2">
//         <div className="chart-text mr-2">
//           <h6 className="mb-0">
//             <small>THIS MONTH</small>
//           </h6>
//           <h4 className="mt-0 text-info">$58,356</h4>
//         </div>
//         <div className="spark-chart">
//           <div id="monthchart" />
//         </div>
//       </div>
//       <div className="d-flex ml-2">
//         <div className="chart-text mr-2">
//           <h6 className="mb-0">
//             <small>LAST MONTH</small>
//           </h6>
//           <h4 className="mt-0 text-primary">$48,356</h4>
//         </div>
//         <div className="spark-chart">
//           <div id="lastmonthchart" />
//         </div>
//       </div>
//     </div>
//   </div>
// </div>

//   )
// }

// export default Breadcrumb
